package com.example.manualcam

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.widget.SeekBar

/** SeekBar drawn as a tick ruler with a value bubble (like pro camera apps). */
class RulerBar(ctx: Context) : SeekBar(ctx) {
    var label = ""
    private val d = ctx.resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        thumb = null
        background = null
        setPadding((d * 16).toInt(), 0, (d * 16).toInt(), 0)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val l = paddingLeft.toFloat()
        val r = w - paddingRight
        val frac = if (max > 0) progress.toFloat() / max else 0f
        val x = l + (r - l) * frac
        p.style = Paint.Style.STROKE; p.strokeWidth = d
        p.color = 0xCCFFFFFF.toInt()
        var tx = l; var i = 0
        while (tx <= r + 1) {
            val len = if (i % 5 == 0) d * 16 else d * 9
            c.drawLine(tx, h - d * 6, tx, h - d * 6 - len, p)
            tx += d * 9; i++
        }
        p.color = 0xFF42A5F5.toInt(); p.strokeWidth = d * 2.5f
        c.drawLine(x, d * 24, x, h - d * 3, p)
        p.style = Paint.Style.FILL
        p.textSize = d * 13; p.typeface = Typeface.DEFAULT_BOLD; p.textAlign = Paint.Align.CENTER
        val bw = p.measureText(label) + d * 22
        val bh = d * 24
        val bx = (x - bw / 2).coerceIn(0f, (w - bw).coerceAtLeast(0f))
        p.color = 0xDD37474F.toInt()
        c.drawRoundRect(bx, 0f, bx + bw, bh, d * 7, d * 7, p)
        p.color = 0xFFFFFFFF.toInt()
        c.drawText(label, bx + bw / 2, bh - d * 7, p)
    }
}
