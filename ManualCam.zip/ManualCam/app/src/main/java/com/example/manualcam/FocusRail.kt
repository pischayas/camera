package com.example.manualcam

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.MotionEvent
import android.view.View
import kotlin.math.roundToInt

/** Vertical manual-focus rail: top = infinity, bottom = nearest focus. Drag to pull focus. */
class FocusRail(ctx: Context) : View(ctx) {
    var frac = 1f
        set(v) { field = v.coerceIn(0f, 1f); invalidate() }
    var minFocus = 0f
        set(v) { field = v; invalidate() }
    var onChange: ((Float) -> Unit)? = null

    private val d = ctx.resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val pad = d * 16
        val x = w * 0.66f
        p.style = Paint.Style.FILL; p.color = 0x77000000
        c.drawRoundRect(0f, 0f, w, h, d * 8, d * 8, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = d * 1.5f; p.color = 0xCCFFFFFF.toInt()
        c.drawLine(x, pad, x, h - pad, p)
        for (i in 0..10) {
            val y = pad + (h - 2 * pad) * i / 10
            val len = if (i % 5 == 0) d * 10 else d * 5
            c.drawLine(x - len, y, x, y, p)
        }
        p.style = Paint.Style.FILL; p.textSize = d * 10; p.textAlign = Paint.Align.CENTER; p.color = 0xFFFFFFFF.toInt()
        c.drawText("∞", w / 2, d * 12, p)
        c.drawText(if (minFocus > 0f) "${(100f / minFocus).roundToInt()}cm" else "", w / 2, h - d * 3, p)
        val hy = pad + (h - 2 * pad) * (1 - frac)
        p.color = 0xFFFFEB3B.toInt()
        c.drawCircle(x, hy, d * 9, p)
        p.textAlign = Paint.Align.RIGHT; p.textSize = d * 9
        val dist = if (frac >= 0.99f || minFocus <= 0f) "∞" else "%.2fm".format(1f / (minFocus * (1 - frac)))
        c.drawText(dist, x - d * 12, hy + d * 3, p)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_DOWN || e.actionMasked == MotionEvent.ACTION_MOVE) {
            val pad = d * 16
            frac = 1f - (e.y - pad) / (height - 2 * pad)
            onChange?.invoke(frac)
            parent?.requestDisallowInterceptTouchEvent(true)
        }
        return true
    }
}
