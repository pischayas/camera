package com.example.manualcam

/** Minimal .cube (3D LUT) parser. The LUT is packed into a strip texture: x = blue*N + red, y = green. */
object CubeLut {
    class Lut(val size: Int, val rgba: ByteArray)

    fun parse(text: String): Lut {
        var n = 0
        var data = FloatArray(0)
        var count = 0
        for (raw in text.lineSequence()) {
            val line = raw.trim()
            if (line.isEmpty() || line.startsWith("#")) continue
            val c = line[0]
            if (c.isLetter()) {
                val p = line.split(Regex("\\s+"))
                when (p[0].uppercase()) {
                    "LUT_3D_SIZE" -> {
                        n = p[1].toInt()
                        if (n < 2 || n > 64) throw IllegalArgumentException("LUT size $n not supported (2..64)")
                        data = FloatArray(n * n * n * 3)
                    }
                    "LUT_1D_SIZE" -> throw IllegalArgumentException("1D LUT is not supported (need LUT_3D_SIZE)")
                }
                continue
            }
            if (c.isDigit() || c == '-' || c == '.' || c == '+') {
                if (n == 0) throw IllegalArgumentException("LUT_3D_SIZE missing before data")
                val p = line.split(Regex("\\s+"))
                if (p.size < 3 || count + 3 > data.size) continue
                data[count++] = p[0].toFloat(); data[count++] = p[1].toFloat(); data[count++] = p[2].toFloat()
            }
        }
        if (n == 0 || count < n * n * n * 3) throw IllegalArgumentException("incomplete LUT ($count of ${n * n * n * 3} values)")
        val w = n * n
        val out = ByteArray(w * n * 4)
        for (i in 0 until n * n * n) {
            val r = i % n
            val g = (i / n) % n
            val b = i / (n * n)
            val pos = (g * w + (b * n + r)) * 4
            for (k in 0..2) out[pos + k] = (data[i * 3 + k].coerceIn(0f, 1f) * 255f + 0.5f).toInt().toByte()
            out[pos + 3] = 255.toByte()
        }
        return Lut(n, out)
    }
}
