package com.example.manualcam

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.View
import kotlin.math.min

/** Round record button: white ring + red dot (red rounded square while recording). */
class RecButton(ctx: Context) : View(ctx) {
    var text: CharSequence = "REC"
        set(v) { field = v; on = v.toString() == "STOP"; invalidate() }
    private var on = false
    private val d = ctx.resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = min(width, height) / 2f - d * 3
        p.style = Paint.Style.STROKE; p.strokeWidth = d * 3; p.color = 0xFFFFFFFF.toInt()
        c.drawCircle(cx, cy, r, p)
        p.style = Paint.Style.FILL; p.color = 0xFFE53935.toInt()
        if (on) c.drawRoundRect(RectF(cx - r * 0.45f, cy - r * 0.45f, cx + r * 0.45f, cy + r * 0.45f), d * 6, d * 6, p)
        else c.drawCircle(cx, cy, r * 0.72f, p)
    }
}
