package com.example.manualcam

import android.graphics.SurfaceTexture
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLExt
import android.opengl.EGLSurface
import android.opengl.GLES20
import android.opengl.Matrix
import android.os.Handler
import android.os.HandlerThread
import android.view.Surface
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Camera -> OpenGL (look, log profile, 3D LUT) -> preview surface + recorder surface.
 * Everything drawn here is what ends up in the recorded file (the LUT can be limited to the preview).
 */
class GlPipeline(
    private val previewTex: SurfaceTexture,
    private val camW: Int,
    private val camH: Int,
    private val outW: Int,
    private val outH: Int,
    private val extraRot: Int
) {
    @Volatile private var look = 0
    @Volatile private var logP = 0          // 0 off, 1 LogC, 2 S-Log3
    @Volatile private var lutMode = 0       // 0 off, 1 preview only, 2 preview + file
    @Volatile private var lutMix = 1f

    private val thread = HandlerThread("glpipe").also { it.start() }
    private val h = Handler(thread.looper)
    private var display: EGLDisplay = EGL14.EGL_NO_DISPLAY
    private var context: EGLContext = EGL14.EGL_NO_CONTEXT
    private var config: EGLConfig? = null
    private var previewSurf: EGLSurface = EGL14.EGL_NO_SURFACE
    private var recSurf: EGLSurface = EGL14.EGL_NO_SURFACE
    private var camTexId = 0
    private var lutTexId = 0
    private var camTex: SurfaceTexture? = null
    private var camSurface: Surface? = null
    private var program = 0
    @Volatile private var released = false

    private var lutSize = 0
    private var pendingLut: ByteBuffer? = null
    private var pendingLutSize = 0
    private var lutDirty = false

    private val texMat = FloatArray(16)
    private val rotMat = FloatArray(16)
    private val mvp = FloatArray(16)
    private val vBuf: FloatBuffer = buf(floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f))
    private val tBuf: FloatBuffer = buf(floatArrayOf(0f, 0f, 1f, 0f, 0f, 1f, 1f, 1f))

    private var aPos = 0; private var aTex = 0
    private var uTex = 0; private var uCam = 0; private var uLut = 0
    private var uLutSize = 0; private var uLutMix = 0; private var uUseLut = 0; private var uLog = 0; private var uLook = 0

    private fun buf(a: FloatArray): FloatBuffer =
        ByteBuffer.allocateDirect(a.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().also { it.put(a); it.position(0) }

    // ------------------------------------------------------------------ public api

    fun setParams(look: Int, logProfile: Int, lutMode: Int, mix: Float) {
        this.look = look; this.logP = logProfile; this.lutMode = lutMode; this.lutMix = mix
    }

    fun setLut(size: Int, rgba: ByteArray?) {
        h.post {
            pendingLutSize = size
            pendingLut = rgba?.let { ByteBuffer.allocateDirect(it.size).order(ByteOrder.nativeOrder()).put(it).also { b -> b.position(0) } }
            lutDirty = true
        }
    }

    /** Creates the GL context and returns the surface the camera must write to. */
    fun start(): Surface {
        var err: Throwable? = null
        val latch = CountDownLatch(1)
        h.post {
            try { setup() } catch (t: Throwable) { err = t } finally { latch.countDown() }
        }
        if (!latch.await(4, TimeUnit.SECONDS)) throw RuntimeException("GL init timeout")
        err?.let { throw it }
        return camSurface ?: throw RuntimeException("no camera surface")
    }

    fun startRecording(s: Surface) {
        var err: Throwable? = null
        val latch = CountDownLatch(1)
        h.post {
            try { recSurf = EGL14.eglCreateWindowSurface(display, config, s, intArrayOf(EGL14.EGL_NONE), 0) }
            catch (t: Throwable) { err = t } finally { latch.countDown() }
        }
        latch.await(2, TimeUnit.SECONDS)
        err?.let { throw it }
    }

    fun stopRecording() {
        val latch = CountDownLatch(1)
        h.post {
            try {
                if (recSurf != EGL14.EGL_NO_SURFACE) {
                    EGL14.eglMakeCurrent(display, previewSurf, previewSurf, context)
                    EGL14.eglDestroySurface(display, recSurf)
                    recSurf = EGL14.EGL_NO_SURFACE
                }
            } catch (_: Throwable) {}
            latch.countDown()
        }
        latch.await(2, TimeUnit.SECONDS)
    }

    fun release() {
        val latch = CountDownLatch(1)
        h.post {
            released = true
            try {
                EGL14.eglMakeCurrent(display, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
                if (recSurf != EGL14.EGL_NO_SURFACE) EGL14.eglDestroySurface(display, recSurf)
                if (previewSurf != EGL14.EGL_NO_SURFACE) EGL14.eglDestroySurface(display, previewSurf)
                if (context != EGL14.EGL_NO_CONTEXT) EGL14.eglDestroyContext(display, context)
                EGL14.eglReleaseThread()
            } catch (_: Throwable) {}
            try { camSurface?.release() } catch (_: Throwable) {}
            try { camTex?.release() } catch (_: Throwable) {}
            latch.countDown()
        }
        latch.await(2, TimeUnit.SECONDS)
        thread.quitSafely()
    }

    // ------------------------------------------------------------------ GL thread

    private fun setup() {
        previewTex.setDefaultBufferSize(outW, outH)
        display = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        val ver = IntArray(2)
        if (!EGL14.eglInitialize(display, ver, 0, ver, 1)) throw RuntimeException("eglInitialize failed")
        val attrs = intArrayOf(
            EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8, EGL14.EGL_BLUE_SIZE, 8, EGL14.EGL_ALPHA_SIZE, 8,
            EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
            0x3142, 1,                      // EGL_RECORDABLE_ANDROID
            EGL14.EGL_NONE
        )
        val cfgs = arrayOfNulls<EGLConfig>(1)
        val num = IntArray(1)
        EGL14.eglChooseConfig(display, attrs, 0, cfgs, 0, 1, num, 0)
        if (num[0] <= 0 || cfgs[0] == null) throw RuntimeException("no EGL config")
        config = cfgs[0]
        context = EGL14.eglCreateContext(display, config, EGL14.EGL_NO_CONTEXT, intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE), 0)
        previewSurf = EGL14.eglCreateWindowSurface(display, config, previewTex, intArrayOf(EGL14.EGL_NONE), 0)
        if (previewSurf == EGL14.EGL_NO_SURFACE) throw RuntimeException("preview EGL surface failed")
        EGL14.eglMakeCurrent(display, previewSurf, previewSurf, context)

        program = buildProgram()
        aPos = GLES20.glGetAttribLocation(program, "aPos"); aTex = GLES20.glGetAttribLocation(program, "aTex")
        uTex = GLES20.glGetUniformLocation(program, "uTex"); uCam = GLES20.glGetUniformLocation(program, "uCam")
        uLut = GLES20.glGetUniformLocation(program, "uLut"); uLutSize = GLES20.glGetUniformLocation(program, "uLutSize")
        uLutMix = GLES20.glGetUniformLocation(program, "uLutMix"); uUseLut = GLES20.glGetUniformLocation(program, "uUseLut")
        uLog = GLES20.glGetUniformLocation(program, "uLog"); uLook = GLES20.glGetUniformLocation(program, "uLook")

        val t = IntArray(1)
        GLES20.glGenTextures(1, t, 0)
        camTexId = t[0]
        GLES20.glBindTexture(OES, camTexId)
        GLES20.glTexParameteri(OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(OES, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(OES, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)

        val st = SurfaceTexture(camTexId)
        st.setDefaultBufferSize(camW, camH)
        st.setOnFrameAvailableListener({ if (!released) draw() }, h)
        camTex = st
        camSurface = Surface(st)
    }

    private fun draw() {
        val st = camTex ?: return
        try {
            EGL14.eglMakeCurrent(display, previewSurf, previewSurf, context)
            st.updateTexImage()
        } catch (_: Throwable) { return }
        st.getTransformMatrix(texMat)
        Matrix.setIdentityM(rotMat, 0)
        if (extraRot != 0) {
            Matrix.translateM(rotMat, 0, 0.5f, 0.5f, 0f)
            Matrix.rotateM(rotMat, 0, extraRot.toFloat(), 0f, 0f, 1f)
            Matrix.translateM(rotMat, 0, -0.5f, -0.5f, 0f)
        }
        Matrix.multiplyMM(mvp, 0, texMat, 0, rotMat, 0)
        uploadLut()
        render(previewSurf, false)
        if (recSurf != EGL14.EGL_NO_SURFACE) render(recSurf, true)
    }

    private fun uploadLut() {
        if (!lutDirty) return
        lutDirty = false
        val b = pendingLut
        if (b == null || pendingLutSize < 2) { lutSize = 0; return }
        if (lutTexId == 0) {
            val t = IntArray(1)
            GLES20.glGenTextures(1, t, 0)
            lutTexId = t[0]
        }
        GLES20.glActiveTexture(GLES20.GL_TEXTURE1)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, lutTexId)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glPixelStorei(GLES20.GL_UNPACK_ALIGNMENT, 1)
        GLES20.glTexImage2D(GLES20.GL_TEXTURE_2D, 0, GLES20.GL_RGBA, pendingLutSize * pendingLutSize, pendingLutSize, 0,
            GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, b)
        lutSize = pendingLutSize
    }

    private fun render(surf: EGLSurface, forFile: Boolean) {
        EGL14.eglMakeCurrent(display, surf, surf, context)
        GLES20.glViewport(0, 0, outW, outH)
        GLES20.glUseProgram(program)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(OES, camTexId)
        GLES20.glUniform1i(uCam, 0)
        if (lutTexId != 0) {
            GLES20.glActiveTexture(GLES20.GL_TEXTURE1)
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, lutTexId)
        }
        GLES20.glUniform1i(uLut, 1)
        val useLut = lutSize > 0 && ((forFile && lutMode == 2) || (!forFile && lutMode >= 1))
        GLES20.glUniformMatrix4fv(uTex, 1, false, mvp, 0)
        GLES20.glUniform1f(uLutSize, lutSize.toFloat())
        GLES20.glUniform1f(uLutMix, lutMix)
        GLES20.glUniform1f(uUseLut, if (useLut) 1f else 0f)
        GLES20.glUniform1f(uLog, logP.toFloat())
        GLES20.glUniform1f(uLook, look.toFloat())
        GLES20.glEnableVertexAttribArray(aPos)
        GLES20.glVertexAttribPointer(aPos, 2, GLES20.GL_FLOAT, false, 0, vBuf)
        GLES20.glEnableVertexAttribArray(aTex)
        GLES20.glVertexAttribPointer(aTex, 2, GLES20.GL_FLOAT, false, 0, tBuf)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        GLES20.glDisableVertexAttribArray(aPos)
        GLES20.glDisableVertexAttribArray(aTex)
        if (forFile) EGLExt.eglPresentationTimeANDROID(display, surf, System.nanoTime())
        EGL14.eglSwapBuffers(display, surf)
    }

    private fun buildProgram(): Int {
        val vs = compile(GLES20.GL_VERTEX_SHADER, VERTEX)
        val fs = compile(GLES20.GL_FRAGMENT_SHADER, FRAGMENT)
        val p = GLES20.glCreateProgram()
        GLES20.glAttachShader(p, vs); GLES20.glAttachShader(p, fs)
        GLES20.glLinkProgram(p)
        val ok = IntArray(1)
        GLES20.glGetProgramiv(p, GLES20.GL_LINK_STATUS, ok, 0)
        if (ok[0] == 0) throw RuntimeException("link: " + GLES20.glGetProgramInfoLog(p))
        return p
    }

    private fun compile(type: Int, src: String): Int {
        val s = GLES20.glCreateShader(type)
        GLES20.glShaderSource(s, src)
        GLES20.glCompileShader(s)
        val ok = IntArray(1)
        GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0)
        if (ok[0] == 0) throw RuntimeException("shader: " + GLES20.glGetShaderInfoLog(s))
        return s
    }

    companion object {
        private const val OES = 0x8D65   // GL_TEXTURE_EXTERNAL_OES

        private const val VERTEX = """
attribute vec4 aPos;
attribute vec2 aTex;
uniform mat4 uTex;
varying vec2 vTex;
void main() {
    gl_Position = aPos;
    vTex = (uTex * vec4(aTex, 0.0, 1.0)).xy;
}
"""

        private const val FRAGMENT = """
#extension GL_OES_EGL_image_external : require
precision highp float;
varying vec2 vTex;
uniform samplerExternalOES uCam;
uniform sampler2D uLut;
uniform float uLutSize;
uniform float uLutMix;
uniform float uUseLut;
uniform float uLog;
uniform float uLook;
const float LN10 = 2.302585;

vec3 toLin(vec3 c) {
    return mix(c / 12.92, pow((c + 0.055) / 1.055, vec3(2.4)), step(vec3(0.04045), c));
}
vec3 logC(vec3 x) {
    vec3 lo = 5.367655 * x + 0.092809;
    vec3 hi = 0.24719 * (log(5.555556 * x + 0.052272) / LN10) + 0.385537;
    return mix(lo, hi, step(vec3(0.010591), x));
}
vec3 sLog3(vec3 x) {
    vec3 hi = (420.0 + (log((x + 0.01) / 0.19) / LN10) * 261.5) / 1023.0;
    vec3 lo = (x * (171.2102946929 - 95.0) / 0.01125 + 95.0) / 1023.0;
    return mix(lo, hi, step(vec3(0.01125), x));
}
vec3 lut3(vec3 c) {
    float n = uLutSize;
    float bs = c.b * (n - 1.0);
    float b0 = floor(bs);
    float b1 = min(b0 + 1.0, n - 1.0);
    float f = bs - b0;
    float y = (c.g * (n - 1.0) + 0.5) / n;
    float x0 = (b0 * n + c.r * (n - 1.0) + 0.5) / (n * n);
    float x1 = (b1 * n + c.r * (n - 1.0) + 0.5) / (n * n);
    return mix(texture2D(uLut, vec2(x0, y)).rgb, texture2D(uLut, vec2(x1, y)).rgb, f);
}
vec3 applyLook(vec3 c, float id) {
    float l = dot(c, vec3(0.2126, 0.7152, 0.0722));
    if (id < 0.5) return c;
    if (id < 1.5) return vec3(l);
    if (id < 2.5) {
        vec3 s = c + 0.5 * (c * c * (3.0 - 2.0 * c) - c);
        vec3 shadow = vec3(0.0, 0.03, 0.05) * (1.0 - l);
        vec3 high = vec3(0.05, 0.02, -0.03) * l;
        return clamp(s + shadow + high, 0.0, 1.0);
    }
    if (id < 3.5) {
        vec3 s = mix(vec3(l), c, 1.45);
        s = s + 0.35 * (s * s * (3.0 - 2.0 * s) - s);
        return clamp(s, 0.0, 1.0);
    }
    if (id < 4.5) return clamp(c * vec3(1.08, 1.0, 0.92), 0.0, 1.0);
    return clamp(c * vec3(0.92, 1.0, 1.08), 0.0, 1.0);
}
void main() {
    vec3 c = texture2D(uCam, vTex).rgb;
    c = applyLook(c, uLook);
    if (uLog > 0.5) {
        vec3 x = max(toLin(c), vec3(0.0));
        if (uLog < 1.5) c = logC(x); else c = sLog3(x);
    }
    if (uUseLut > 0.5) {
        vec3 g = lut3(clamp(c, 0.0, 1.0));
        c = mix(c, g, uLutMix);
    }
    gl_FragColor = vec4(clamp(c, 0.0, 1.0), 1.0);
}
"""
    }
}
