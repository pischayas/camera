pluginManagement {
    repositories { google(); mavenCentral(); gradlePluginPortal() }
}
dependencyResolutionManagement {
    repositories {
        google()
        mavenCentral()
        maven {
            url = uri("https://developer.huawei.com/repo/")
            // Huawei publishes camerakit as a bare .aar (docs use "ext: 'aar'"), so also accept artifacts without a .pom
            metadataSources { mavenPom(); artifact() }
        }
    }
}
rootProject.name = "HWManualCam"
include(":app")
