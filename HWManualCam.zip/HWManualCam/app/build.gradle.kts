plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// -PwithHw=true  -> compile the Huawei Camera Engine screen (needs the camerakit AAR from Huawei's Maven repo)
val withHw = (project.findProperty("withHw") as String?) == "true"

android {
    namespace = "com.example.manualcam"
    compileSdk = 36

    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    defaultConfig {
        applicationId = "com.example.hwmanualcam"
        minSdk = 30
        targetSdk = 36
        versionCode = 1
        versionName = "1.0"
    }
    sourceSets {
        getByName("main") {
            if (withHw) java.srcDir("src/hw/java")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    if (withHw) {
        implementation("com.huawei.multimedia:camerakit:1.1.3@aar")
    }
}
