package com.example.manualcam.hw

import android.Manifest
import android.app.Activity
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.ImageFormat
import android.graphics.Rect
import android.graphics.SurfaceTexture
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CaptureRequest
import android.media.MediaCodec
import android.media.MediaRecorder
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.provider.MediaStore
import android.util.Range
import android.util.Size
import android.view.Gravity
import android.view.MotionEvent
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import com.huawei.camera.camerakit.ActionDataCallback
import com.huawei.camera.camerakit.ActionStateCallback
import com.huawei.camera.camerakit.CameraKit
import com.huawei.camera.camerakit.Metadata
import com.huawei.camera.camerakit.Mode
import com.huawei.camera.camerakit.ModeCharacteristics
import com.huawei.camera.camerakit.ModeStateCallback
import com.huawei.camera.camerakit.RequestKey
import java.io.File
import kotlin.math.abs
import kotlin.math.roundToInt

/** TextureView that keeps the preview aspect ratio (same idea as the official demo's AutoFitTextureView). */
private class FitTextureView(ctx: Context) : TextureView(ctx) {
    private var rw = 0
    private var rh = 0
    fun setAspect(w: Int, h: Int) { rw = w; rh = h; requestLayout() }
    override fun onMeasure(wSpec: Int, hSpec: Int) {
        super.onMeasure(wSpec, hSpec)
        val w = MeasureSpec.getSize(wSpec)
        val h = MeasureSpec.getSize(hSpec)
        if (rw == 0 || rh == 0) setMeasuredDimension(w, h)
        else if (w < h * rw / rh) setMeasuredDimension(w, w * rh / rw)
        else setMeasuredDimension(h * rw / rh, h)
    }
}

/**
 * Huawei Camera Engine (camerakit 1.1.5) "Pro Video" screen, structured like Huawei's official ProVideoMode demo:
 *  - the app owns a MediaRecorder fed by MediaCodec.createPersistentInputSurface(), added with addVideoSurface()
 *  - mode.startRecording() / stopRecording() are called together with recorder.start() / stop()
 *  - ISO, EV, white balance, manual focus, metering use RequestKey.HW_PRO_* parameters
 */
class HwProActivity : Activity() {

    private val ui = Handler(Looper.getMainLooper())
    private var bgThread: HandlerThread? = null
    private var stThread: HandlerThread? = null
    private var dtThread: HandlerThread? = null
    private var mdThread: HandlerThread? = null
    private var bgH: Handler? = null
    private var stH: Handler? = null
    private var dtH: Handler? = null
    private var mdH: Handler? = null

    private var kit: CameraKit? = null
    private var mode: Mode? = null
    private var chars: ModeCharacteristics? = null
    private var cameraId = "0"
    private var starting = false

    private var recordSize: Size? = null
    private var previewSize: Size? = null
    private var captureSize: Size? = null
    private var previewSurface: Surface? = null
    private var videoSurface: Surface? = null
    private var recorder: MediaRecorder? = null
    private var videoPath = ""
    private var recording = false
    private var firstRecording = true
    private var fps = 30
    private var recStartMs = 0L

    private lateinit var tv: FitTextureView
    private lateinit var logTxt: TextView
    private lateinit var ctlBox: LinearLayout
    private lateinit var recBtn: Button
    private val logLines = ArrayList<String>()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun say(s: String) {
        ui.post {
            logLines.add(s)
            while (logLines.size > 60) logLines.removeAt(0)
            logTxt.text = logLines.joinToString("\n")
        }
    }

    private fun btn(t: String, f: () -> Unit) = Button(this).apply {
        text = t; textSize = 11f; isAllCaps = false; setTextColor(Color.WHITE)
        setBackgroundColor(0x99000000.toInt())
        setPadding(dp(6), dp(4), dp(6), dp(4)); minHeight = 0; minimumHeight = 0
        setOnClickListener { f() }
    }

    // ------------------------------------------------------------------ lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        tv = FitTextureView(this)
        root.addView(tv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.TOP or Gravity.CENTER_HORIZONTAL))
        tv.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(s: SurfaceTexture, w: Int, h: Int) { startMode() }
            override fun onSurfaceTextureSizeChanged(s: SurfaceTexture, w: Int, h: Int) {}
            override fun onSurfaceTextureDestroyed(s: SurfaceTexture) = true
            override fun onSurfaceTextureUpdated(s: SurfaceTexture) {}
        }
        tv.setOnTouchListener { v, e ->
            if (e.action == MotionEvent.ACTION_UP) tapFocus(e.x.toInt(), e.y.toInt(), v.width, v.height)
            true
        }

        logTxt = TextView(this).apply { setTextColor(0xFFB9F6CA.toInt()); textSize = 9f; setPadding(dp(8), dp(24), dp(8), dp(4)) }
        val logScroll = ScrollView(this).apply { setBackgroundColor(0x77000000); addView(logTxt) }
        root.addView(logScroll, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(120), Gravity.TOP))

        ctlBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(4), dp(8), dp(4)) }
        val ctlScroll = ScrollView(this).apply { setBackgroundColor(0xAA000000.toInt()); addView(ctlBox) }

        recBtn = btn("REC") { toggleRec() }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setBackgroundColor(0xFF0B1220.toInt())
            setPadding(dp(6), dp(6), dp(6), dp(6))
            for (f in listOf(24, 30, 60)) addView(btn("FPS $f") { setFps(f) }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            addView(recBtn, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.3f))
            addView(btn("BACK") { finish() }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(ctlScroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(250)))
            addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        root.addView(bottom, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))
        setContentView(root)
    }

    private fun hasPerms() =
        checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    override fun onResume() {
        super.onResume()
        startThreads()
        if (!hasPerms()) { requestPermissions(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO), 1); return }
        try {
            kit = CameraKit.getInstance(applicationContext)
        } catch (e: Throwable) { say("CameraKit.getInstance error: $e") }
        if (kit == null) { say("อุปกรณ์นี้ไม่รองรับ Camera Engine หรือยังไม่ได้ติดตั้ง (CameraKit.getInstance = null)"); return }
        if (tv.isAvailable) startMode()
    }

    override fun onPause() {
        releaseAll()
        stopThreads()
        super.onPause()
    }

    private fun startThreads() {
        fun mk(n: String) = HandlerThread(n).also { it.start() }
        if (bgThread == null) { bgThread = mk("hw-bg"); bgH = Handler(bgThread!!.looper) }
        if (stThread == null) { stThread = mk("hw-status"); stH = Handler(stThread!!.looper) }
        if (dtThread == null) { dtThread = mk("hw-data"); dtH = Handler(dtThread!!.looper) }
        if (mdThread == null) { mdThread = mk("hw-mode"); mdH = Handler(mdThread!!.looper) }
    }

    private fun stopThreads() {
        for (t in listOf(bgThread, stThread, dtThread, mdThread)) {
            t?.quitSafely()
            try { t?.join(500) } catch (_: Exception) {}
        }
        bgThread = null; stThread = null; dtThread = null; mdThread = null
        bgH = null; stH = null; dtH = null; mdH = null
    }

    // ------------------------------------------------------------------ mode creation (as in the official demo)

    private val stateCb = object : ModeStateCallback() {
        override fun onCreated(m: Mode) {
            mode = m
            say("mode created")
            try {
                prepareConfig()
                configureMode(m)
            } catch (e: Throwable) { starting = false; say("configure error: $e") }
        }

        override fun onConfigured(m: Mode) {
            try {
                m.startPreview()
                say("preview started")
                starting = false
                ui.post { buildControls() }
            } catch (e: Throwable) { say("startPreview error: $e") }
        }

        override fun onReleased(m: Mode) { say("mode released") }
    }

    private val actionState = object : ActionStateCallback() {}
    private val actionData = object : ActionDataCallback() {}

    private fun startMode() {
        val k = kit ?: return
        if (mode != null || starting) return
        starting = true
        try {
            val ids = k.cameraIdList
            say("camera ids: " + ids.joinToString())
            var chosen = ""
            for (id in (listOf("0") + ids.toList()).distinct()) {
                val sm = try { k.getSupportedModes(id) } catch (_: Throwable) { null }
                say("  id $id modes: " + (sm?.joinToString() ?: "-"))
                if (chosen.isEmpty() && sm != null && sm.contains(Mode.Type.PRO_VIDEO_MODE)) chosen = id
            }
            if (chosen.isEmpty()) { say("ไม่มีกล้องที่รองรับ PRO_VIDEO_MODE"); starting = false; return }
            cameraId = chosen
            say("create PRO_VIDEO_MODE on camera $cameraId")
            bgH?.post {
                try { k.createMode(cameraId, Mode.Type.PRO_VIDEO_MODE, stateCb, mdH) }
                catch (e: Throwable) { starting = false; say("createMode error: $e") }
            }
        } catch (e: Throwable) {
            starting = false
            say("start error: $e")
        }
    }

    private fun prepareConfig() {
        val k = kit ?: return
        val c = k.getModeCharacteristics(cameraId, Mode.Type.PRO_VIDEO_MODE)
        chars = c
        val previewSizes: List<Size> = c.getSupportedPreviewSizes(SurfaceTexture::class.java) ?: emptyList()
        val captureSizes: List<Size> = c.getSupportedCaptureSizes(ImageFormat.JPEG) ?: emptyList()
        val vmap = c.getSupportedVideoSizes(MediaRecorder::class.java)
        say("video sizes: $vmap")
        val recList: List<Size> = vmap?.get(fps) ?: vmap?.get(30) ?: vmap?.values?.firstOrNull() ?: emptyList()
        val rs = recList.maxByOrNull { it.width * it.height } ?: Size(1920, 1080)
        recordSize = rs
        captureSize = pickCaptureSize(rs, captureSizes)
        val ps = pickPreviewSize(rs, previewSizes)
        previewSize = ps
        say("record ${rs.width}x${rs.height}  preview ${ps.width}x${ps.height}  fps $fps")
        ui.post { tv.setAspect(ps.height, ps.width) }   // portrait: swap
        val st = tv.surfaceTexture
        if (st != null) {
            st.setDefaultBufferSize(ps.width, ps.height)
            previewSurface = Surface(st)
        }
        videoSurface = MediaCodec.createPersistentInputSurface()
        prepareRecorder()
        firstRecording = true
    }

    private fun configureMode(m: Mode) {
        val b = m.modeConfigBuilder
        b.setStateCallback(actionState, stH)
        b.setDataCallback(actionData, dtH)
        captureSize?.let { b.addCaptureImage(it, ImageFormat.JPEG) }
        videoSurface?.let { b.addVideoSurface(it) }
        previewSurface?.let { b.addPreviewSurface(it) }
        m.configure()
    }

    private fun pickCaptureSize(rec: Size, list: List<Size>): Size {
        val ratio = rec.height.toFloat() / rec.width
        var best: Size? = null
        for (s in list) if (abs(s.height.toFloat() / s.width - ratio) < 0.01f && (best == null || best.width < s.width)) best = s
        return best ?: list.maxByOrNull { it.width * it.height } ?: rec
    }

    private fun pickPreviewSize(rec: Size, list: List<Size>): Size {
        val ratio = rec.width.toDouble() / rec.height
        var best: Size? = null
        for (s in list) {
            if (abs(s.width.toDouble() / s.height - ratio) > 0.05) continue
            val b = best
            if (b == null || (abs(s.height - rec.height) <= abs(b.height - rec.height) && abs(s.width - rec.width) <= abs(b.width - rec.width))) best = s
        }
        return best ?: list.firstOrNull() ?: rec
    }

    private fun releaseAll() {
        try {
            if (recording) { mode?.stopRecording(); recorder?.stop() }
        } catch (_: Throwable) {}
        recording = false
        try { mode?.release() } catch (_: Throwable) {}
        mode = null; chars = null; starting = false
        try { recorder?.reset() } catch (_: Throwable) {}
        try { recorder?.release() } catch (_: Throwable) {}
        recorder = null
        try { videoSurface?.release() } catch (_: Throwable) {}
        videoSurface = null; previewSurface = null
        runOnUiThread { recBtn.text = "REC"; ctlBox.removeAllViews() }
    }

    private fun setFps(f: Int) {
        if (recording) return
        fps = f
        firstRecording = false            // force a fresh recorder prepare with the new frame rate
        try { mode?.setParameter(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, Range(f, f)) } catch (e: Throwable) { say("fps range: $e") }
        say("target fps $f  (shutter can be at most 1/$f s)")
    }

    // ------------------------------------------------------------------ recorder (own MediaRecorder + persistent surface)

    private fun orientationHint(): Int {
        val so = chars?.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90
        return so % 360                  // activity is locked to portrait: device rotation 0
    }

    private fun newVideoPath(): String {
        val dir = File(getExternalFilesDir(null) ?: filesDir, "HwCameraKit")
        dir.mkdirs()
        return File(dir, "HW_" + System.currentTimeMillis() + ".mp4").path
    }

    private fun prepareRecorder() {
        val rs = recordSize ?: return
        val sur = videoSurface ?: return
        try {
            val r = recorder ?: MediaRecorder().also { recorder = it }
            r.reset()
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setVideoSource(MediaRecorder.VideoSource.SURFACE)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            videoPath = newVideoPath()
            r.setOutputFile(videoPath)
            r.setVideoEncodingBitRate((rs.width.toLong() * rs.height * fps * 0.15).toLong().coerceIn(8_000_000L, 60_000_000L).toInt())
            r.setVideoFrameRate(fps)
            r.setVideoSize(rs.width, rs.height)
            r.setVideoEncoder(MediaRecorder.VideoEncoder.H264)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setOrientationHint(orientationHint())
            r.setInputSurface(sur)
            r.prepare()
            say("recorder ready: $videoPath")
        } catch (e: Throwable) { say("recorder prepare error: $e") }
    }

    private fun toggleRec() {
        val m = mode ?: run { say("ยังไม่พร้อม"); return }
        if (!recording) {
            recording = true
            recBtn.text = "STOP"
            recStartMs = System.currentTimeMillis()
            bgH?.post {
                try {
                    if (!firstRecording) prepareRecorder()
                    firstRecording = false
                    m.startRecording()
                    recorder?.start()
                    say("recording...")
                } catch (e: Throwable) { say("start recording error: $e"); recording = false; runOnUiThread { recBtn.text = "REC" } }
            }
        } else {
            recording = false
            recBtn.text = "REC"
            val path = videoPath
            bgH?.post {
                try { m.stopRecording() } catch (e: Throwable) { say("stopRecording error: $e") }
                try { recorder?.stop() } catch (e: Throwable) { say("recorder.stop error: $e") }
                say("stopped")
                exportToGallery(path)
            }
        }
    }

    private fun exportToGallery(path: String) {
        Thread {
            try {
                val f = File(path)
                if (!f.exists() || f.length() == 0L) { say("ไม่พบไฟล์วิดีโอ: $path"); return@Thread }
                val values = ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME, f.name)
                    put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                    put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/HWManualCam")
                }
                val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                if (uri == null) { say("สร้างไฟล์ปลายทางไม่ได้"); return@Thread }
                contentResolver.openOutputStream(uri)?.use { out -> f.inputStream().use { it.copyTo(out) } }
                f.delete()
                say("บันทึกแล้ว: Movies/HWManualCam/${f.name}")
            } catch (e: Throwable) { say("export error: $e") }
        }.start()
    }

    // ------------------------------------------------------------------ Pro controls (RequestKey.HW_PRO_*)

    private fun <T> range(c: ModeCharacteristics, key: CaptureRequest.Key<T>): List<T> =
        try { c.getParameterRange(key) ?: emptyList() } catch (_: Throwable) { emptyList() }

    private fun label(s: String) = TextView(this).apply { text = s; textSize = 11f; setTextColor(0xFFFFE082.toInt()) }

    private fun <T> listSlider(title: String, values: List<T>, fmt: (T) -> String, onPick: (T) -> Unit): View {
        val value = TextView(this).apply { text = "-"; textSize = 11f; setTextColor(Color.WHITE) }
        val bar = SeekBar(this).apply { max = (values.size - 1).coerceAtLeast(0) }
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (!fromUser || p !in values.indices) return
                value.text = fmt(values[p])
                try { onPick(values[p]) } catch (e: Throwable) { say("$title: $e") }
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(3), 0, dp(3))
            addView(label(title)); addView(value); addView(bar)
        }
    }

    private fun buildControls() {
        val m = mode ?: return
        val c = chars ?: return
        ctlBox.removeAllViews()

        // --- ISO (0 = auto)
        val iso: List<Int> = range(c, RequestKey.HW_PRO_SENSOR_ISO_VALUE)
        say("ISO values: $iso")
        if (iso.isNotEmpty()) ctlBox.addView(listSlider("ISO", iso, { if (it == 0) "AUTO" else it.toString() }) {
            m.setParameter(RequestKey.HW_PRO_SENSOR_ISO_VALUE, it)
        })

        // --- exposure compensation
        val ev: List<Float> = range(c, RequestKey.HW_EXPOSURE_COMPENSATION_VALUE)
        if (ev.isNotEmpty()) ctlBox.addView(listSlider("EV", ev, { "%+.1f".format(it) }) {
            m.setParameter(RequestKey.HW_EXPOSURE_COMPENSATION_VALUE, it)
        })

        // --- focus: AF-C / AF-S / MF
        val af: List<Int> = try { c.supportedAutoFocus.toList() } catch (_: Throwable) { emptyList() }
        say("autofocus modes: $af")
        val afRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val mfBar = listSlider("Manual focus (1 .. 1000)", (1..1000 step 5).toList(), { it.toString() }) {
            m.setParameter(RequestKey.HW_PRO_FOCUS_DISTANCE_VALUE, it.toFloat())
        }
        mfBar.visibility = View.GONE
        if (af.contains(Metadata.FocusMode.HW_AF_CONTINUOUS.toInt())) afRow.addView(btn("AF-C") {
            mfBar.visibility = View.GONE; m.setFocus(Metadata.FocusMode.HW_AF_CONTINUOUS, centerRect())
        })
        if (af.contains(Metadata.FocusMode.HW_AF_TOUCH_LOCK.toInt())) afRow.addView(btn("AF-S") {
            mfBar.visibility = View.GONE; m.setFocus(Metadata.FocusMode.HW_AF_TOUCH_LOCK, centerRect())
        })
        if (af.contains(Metadata.FocusMode.HW_AF_OFF.toInt())) afRow.addView(btn("MF") {
            mfBar.visibility = View.VISIBLE; m.setFocus(Metadata.FocusMode.HW_AF_OFF, null)
        })
        if (afRow.childCount > 0) { ctlBox.addView(label("Focus mode (tap preview = touch focus)")); ctlBox.addView(afRow); ctlBox.addView(mfBar) }

        // --- white balance
        val awbNames = mapOf(1 to "AWB", 6 to "Cloudy", 3 to "Fluorescent", 2 to "Incandescent", 5 to "Sunny", 0 to "Custom (Kelvin)")
        val awb: List<Int> = range(c, RequestKey.HW_PRO_AWB_TYPE)
        val wbR: List<Int> = range(c, RequestKey.HW_PRO_MANUAL_WB_VALUE)
        val kelvinBar = if (wbR.size >= 2) listSlider("Kelvin ${wbR[0]} .. ${wbR[1]}", (0..100).toList(), { (wbR[0] + (it / 100f * (wbR[1] - wbR[0])).roundToInt()).toString() }) {
            m.setParameter(RequestKey.HW_PRO_MANUAL_WB_VALUE, wbR[0] + (it / 100f * (wbR[1] - wbR[0])).roundToInt())
        } else null
        kelvinBar?.visibility = View.GONE
        if (awb.isNotEmpty()) {
            val awbRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (t in awb) awbRow.addView(btn(awbNames[t] ?: "type $t") {
                m.setParameter(RequestKey.HW_PRO_AWB_TYPE, t)
                kelvinBar?.visibility = if (t == 0) View.VISIBLE else View.GONE
            })
            ctlBox.addView(label("White balance")); ctlBox.addView(awbRow)
            kelvinBar?.let { ctlBox.addView(it) }
        }

        // --- metering
        val met: List<Byte> = range(c, RequestKey.HW_PRO_METERING_VALUE)
        if (met.isNotEmpty()) {
            val names = mapOf<Byte, String>(0.toByte() to "Matrix", 1.toByte() to "Spot", 2.toByte() to "Center")
            val metRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (v in met) metRow.addView(btn(names[v] ?: "m$v") { m.setParameter(RequestKey.HW_PRO_METERING_VALUE, v) })
            ctlBox.addView(label("Metering")); ctlBox.addView(metRow)
        }

        // --- shutter: this mode has no exposure-time key; the slowest shutter follows the target frame rate
        ctlBox.addView(label("Shutter: no exposure-time key in Pro Video – use FPS buttons (slowest shutter = 1/fps)"))
        val params = try { c.supportedParameters?.map { it.name } ?: emptyList() } catch (_: Throwable) { emptyList() }
        say("supported parameters (${params.size}): " + params.joinToString(", "))
    }

    private fun centerRect(): Rect {
        val cx = tv.width / 2
        val cy = tv.height / 2
        return Rect(cx - 100, cy - 100, cx + 100, cy + 100)
    }

    private fun tapFocus(x: Int, y: Int, w: Int, h: Int) {
        val m = mode ?: return
        try { m.setFocus(Metadata.FocusMode.HW_AF_TOUCH_LOCK, Rect(x - 100, y - 100, x + 100, y + 100)) } catch (e: Throwable) { say("touch focus: $e") }
    }
}
