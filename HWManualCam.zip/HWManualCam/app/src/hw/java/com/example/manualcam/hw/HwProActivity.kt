package com.example.manualcam.hw

import android.Manifest
import android.app.Activity
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.SurfaceTexture
import android.hardware.camera2.CaptureRequest
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.provider.MediaStore
import android.util.Size
import android.view.Gravity
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import com.huawei.camera.camerakit.CameraKit
import com.huawei.camera.camerakit.Mode
import com.huawei.camera.camerakit.ModeCharacteristics
import com.huawei.camera.camerakit.ModeStateCallback
import java.io.File

/**
 * Huawei Camera Engine (camerakit) "Pro Video" screen.
 *
 * The SDK describes the controls a device really supports (getSupportedParameters / getParameterRange),
 * so this screen builds one slider per supported parameter instead of assuming key names.
 */
class HwProActivity : Activity() {

    private val ui = Handler(Looper.getMainLooper())
    private var thread: HandlerThread? = null
    private var bg: Handler? = null

    private var kit: CameraKit? = null
    private var mode: Mode? = null
    private var chars: ModeCharacteristics? = null
    private var cameraId = ""
    private var fps = 30
    private var recording = false
    private var recStart = 0L
    private var starting = false

    private lateinit var tv: TextureView
    private lateinit var logTxt: TextView
    private lateinit var paramBox: LinearLayout
    private lateinit var recBtn: Button
    private val logLines = ArrayList<String>()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun say(s: String) {
        ui.post {
            logLines.add(s)
            while (logLines.size > 40) logLines.removeAt(0)
            logTxt.text = logLines.joinToString("\n")
        }
    }

    private fun btn(t: String, f: () -> Unit) = Button(this).apply {
        text = t; textSize = 11f; isAllCaps = false; setTextColor(Color.WHITE)
        setBackgroundColor(0x99000000.toInt())
        setOnClickListener { f() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        tv = TextureView(this)
        root.addView(tv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        tv.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(s: SurfaceTexture, w: Int, h: Int) { startEngine() }
            override fun onSurfaceTextureSizeChanged(s: SurfaceTexture, w: Int, h: Int) {}
            override fun onSurfaceTextureDestroyed(s: SurfaceTexture) = true
            override fun onSurfaceTextureUpdated(s: SurfaceTexture) {}
        }

        logTxt = TextView(this).apply { setTextColor(0xFFB9F6CA.toInt()); textSize = 10f; setPadding(dp(8), dp(24), dp(8), dp(4)) }
        val logScroll = ScrollView(this).apply { setBackgroundColor(0x88000000.toInt()); addView(logTxt) }
        root.addView(logScroll, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(170), Gravity.TOP))

        paramBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(4), dp(8), dp(4)) }
        val paramScroll = ScrollView(this).apply { setBackgroundColor(0x99000000.toInt()); addView(paramBox) }

        recBtn = btn("REC") { toggleRec() }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setBackgroundColor(0xFF0B1220.toInt())
            setPadding(dp(6), dp(6), dp(6), dp(6))
            addView(btn("FPS 24") { setFps(24) }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            addView(btn("FPS 30") { setFps(30) }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            addView(btn("FPS 60") { setFps(60) }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            addView(recBtn, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.3f))
            addView(btn("BACK") { finish() }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(paramScroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(230)))
            addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        root.addView(bottom, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))
        setContentView(root)

        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED ||
            checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO), 1)
    }

    override fun onResume() {
        super.onResume()
        if (thread == null) {
            thread = HandlerThread("hwcam").also { it.start() }
            bg = Handler(thread!!.looper)
        }
        if (tv.isAvailable) startEngine()
    }

    override fun onPause() {
        stopEngine()
        thread?.quitSafely(); thread = null; bg = null
        super.onPause()
    }

    // ------------------------------------------------------------------ engine

    private val stateCb = object : ModeStateCallback() {
        override fun onCreated(m: Mode) {
            mode = m
            say("mode created")
            try {
                chars = m.modeCharacteristics
                configure(m)
            } catch (e: Throwable) { say("configure error: $e") }
        }
        override fun onCreateFailed(id: String, modeType: Int, errorCode: Int) { starting = false; say("create failed: camera=$id type=$modeType error=$errorCode") }
        override fun onConfigured(m: Mode) {
            say("configured")
            try { m.startPreview(); say("preview started") } catch (e: Throwable) { say("startPreview error: $e") }
            buildParams()
            starting = false
        }
        override fun onConfigureFailed(m: Mode, errorCode: Int) { starting = false; say("configure failed: $errorCode") }
        override fun onFatalError(m: Mode, errorCode: Int) { say("fatal error: $errorCode") }
        override fun onReleased(m: Mode) { say("released") }
    }

    private fun startEngine() {
        if (starting || mode != null) return
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) { say("ต้องอนุญาตกล้องก่อน"); return }
        starting = true
        try {
            val k = CameraKit.getInstance(applicationContext)
            if (k == null) { say("อุปกรณ์/ระบบนี้ไม่รองรับ Camera Engine (CameraKit.getInstance = null)"); starting = false; return }
            kit = k
            val ids = k.cameraIdList
            say("camera ids: " + ids.joinToString())
            cameraId = ""
            for (id in ids) {
                val modes = k.getSupportedModes(id)
                say("  id $id modes: " + modes.joinToString())
                if (cameraId.isEmpty() && modes.contains(Mode.Type.PRO_VIDEO_MODE)) cameraId = id
            }
            if (cameraId.isEmpty()) { say("ไม่มีกล้องที่รองรับ PRO_VIDEO_MODE"); starting = false; return }
            say("create PRO_VIDEO_MODE on camera $cameraId")
            k.createMode(cameraId, Mode.Type.PRO_VIDEO_MODE, stateCb, bg)
        } catch (e: Throwable) {
            starting = false
            say("start error: $e")
        }
    }

    private fun configure(m: Mode) {
        val st = tv.surfaceTexture ?: return
        st.setDefaultBufferSize(1920, 1080)
        val b = m.modeConfigBuilder
        try { b.setVideoFps(fps) } catch (e: Throwable) { say("setVideoFps: $e") }
        try { b.addVideoSize(Size(1920, 1080)) } catch (e: Throwable) { say("addVideoSize: $e") }
        b.addPreviewSurface(Surface(st))
        m.configure()
    }

    private fun stopEngine() {
        try { if (recording) mode?.stopRecording() } catch (_: Throwable) {}
        recording = false
        try { mode?.release() } catch (_: Throwable) {}
        mode = null; chars = null; starting = false
        runOnUiThread { recBtn.text = "REC"; paramBox.removeAllViews() }
    }

    private fun setFps(f: Int) {
        if (recording) return
        fps = f
        say("fps = $f (restart)")
        stopEngine()
        ui.postDelayed({ startEngine() }, 600)
    }

    // ------------------------------------------------------------------ parameters

    @Suppress("UNCHECKED_CAST")
    private fun buildParams() {
        runOnUiThread {
            paramBox.removeAllViews()
            val m = mode ?: return@runOnUiThread
            val c = chars ?: return@runOnUiThread
            val keys: List<CaptureRequest.Key<*>> = try { c.supportedParameters ?: emptyList() } catch (e: Throwable) { say("getSupportedParameters: $e"); emptyList() }
            say("supported parameters: ${keys.size}")
            val hot = listOf("iso", "exposure", "focus", "temp", "awb", "white", "tint", "zoom", "fps", "aperture")
            val sorted = keys.sortedBy { k -> if (hot.any { k.name.lowercase().contains(it) }) 0 else 1 }
            for (k in sorted) {
                val key = k as CaptureRequest.Key<Any>
                val vals: List<Any> = try { c.getParameterRange(key) ?: emptyList() } catch (e: Throwable) { emptyList() }
                say("  ${key.name}  range=${vals.size}")
                paramBox.addView(paramRow(m, key, vals))
            }
        }
    }

    private fun paramRow(m: Mode, key: CaptureRequest.Key<Any>, vals: List<Any>): View {
        val title = TextView(this).apply { text = key.name; textSize = 10f; setTextColor(0xFFFFE082.toInt()) }
        val value = TextView(this).apply { text = if (vals.isEmpty()) "(no range)" else "-"; textSize = 11f; setTextColor(Color.WHITE) }
        val bar = SeekBar(this).apply { max = (vals.size - 1).coerceAtLeast(0); isEnabled = vals.size > 1 }
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (!fromUser || p !in vals.indices) return
                val v = vals[p]
                value.text = v.toString()
                try { m.setParameter(key, v) } catch (e: Throwable) { say("set ${key.name}=$v failed: $e") }
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(4), 0, dp(4))
            addView(title)
            addView(value)
            addView(bar)
        }
    }

    // ------------------------------------------------------------------ recording

    private fun toggleRec() {
        val m = mode ?: run { say("ยังไม่พร้อม"); return }
        if (!recording) {
            try {
                val dir = getExternalFilesDir(null) ?: filesDir
                recStart = System.currentTimeMillis()
                m.startRecording(dir)
                recording = true
                recBtn.text = "STOP"
                say("recording -> ${dir.path}")
            } catch (e: Throwable) { say("startRecording error: $e") }
        } else {
            try { m.stopRecording() } catch (e: Throwable) { say("stopRecording error: $e") }
            recording = false
            recBtn.text = "REC"
            ui.postDelayed({ exportLatest() }, 2000)
        }
    }

    /** The SDK writes into the app folder; copy the newest clip to Movies/HWManualCam so it shows in the gallery. */
    private fun exportLatest() {
        val dir = getExternalFilesDir(null) ?: filesDir
        Thread {
            try {
                val f = dir.walkTopDown().filter { it.isFile && it.extension.lowercase() in listOf("mp4", "mov") && it.lastModified() >= recStart - 1500 }
                    .maxByOrNull { it.lastModified() }
                if (f == null) { say("ไม่พบไฟล์วิดีโอใน ${dir.path}"); return@Thread }
                val values = ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME, "HW_" + f.name)
                    put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                    put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/HWManualCam")
                }
                val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                if (uri == null) { say("สร้างไฟล์ปลายทางไม่ได้"); return@Thread }
                contentResolver.openOutputStream(uri)?.use { out -> f.inputStream().use { it.copyTo(out) } }
                f.delete()
                say("บันทึกแล้ว: Movies/HWManualCam/HW_${f.name}")
            } catch (e: Throwable) { say("export error: $e") }
        }.start()
    }
}
