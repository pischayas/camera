package com.example.manualcam

import kotlin.math.ln
import kotlin.math.pow

/** Tone-curve profiles (applied through Camera2 TONEMAP_CURVE). */
object Curves {
    private fun srgb(x: Float) = if (x <= 0.0031308f) 12.92f * x else 1.055f * x.pow(1f / 2.4f) - 0.055f

    /** idx 0 = Standard, 1 = Flat (low contrast, wide latitude), 2 = Contrast (S-curve). gain = digital exposure gain (linear). */
    fun curve(idx: Int, gain: Float = 1f): FloatArray {
        val n = 64
        val a = FloatArray(n * 2)
        for (i in 0 until n) {
            val x = i / (n - 1f)
            val s = srgb((x * gain).coerceAtMost(1f))
            val y = when (idx) {
                0 -> s
                1 -> 0.06f + 0.88f * s.pow(0.85f)
                else -> s + 0.6f * (s * s * (3 - 2 * s) - s)
            }
            a[i * 2] = x
            a[i * 2 + 1] = y.coerceIn(0f, 1f)
        }
        return a
    }

    /** Relative RGB (green = 1) of a black-body light at the given temperature. */
    fun kelvinRgb(k: Int): FloatArray {
        val x = k / 100.0
        val r = if (x <= 66) 255.0 else (329.698727446 * (x - 60).pow(-0.1332047592)).coerceIn(0.0, 255.0)
        val g = (if (x <= 66) 99.4708025861 * ln(x) - 161.1195681661 else 288.1221695283 * (x - 60).pow(-0.0755148492)).coerceIn(1.0, 255.0)
        val b = (if (x >= 66) 255.0 else if (x <= 19) 1.0 else 138.5177312231 * ln(x - 10) - 305.0447927307).coerceIn(1.0, 255.0)
        return floatArrayOf((r / g).toFloat(), 1f, (b / g).toFloat())
    }

    /** Per-channel look applied to a tone curve (ch: 0=R 1=G 2=B). look: 2 Cinema, 3 Vivid, 4 Warm, 5 Cool. */
    fun applyLook(a: FloatArray, look: Int, ch: Int): FloatArray {
        if (look < 2) return a
        val o = a.copyOf()
        var i = 1
        while (i < o.size) {
            val y = o[i]
            val v = when (look) {
                2 -> {
                    val s = y + 0.5f * (y * y * (3 - 2 * y) - y)
                    when (ch) {
                        0 -> s + 0.05f * s * s
                        2 -> s + 0.05f * (1 - s) * (1 - s) - 0.03f * s
                        else -> s
                    }
                }
                3 -> y + 0.55f * (y * y * (3 - 2 * y) - y)
                4 -> when (ch) { 0 -> y * 1.08f; 2 -> y * 0.92f; else -> y }
                5 -> when (ch) { 0 -> y * 0.92f; 2 -> y * 1.08f; else -> y }
                else -> y
            }
            o[i] = v.coerceIn(0f, 1f)
            i += 2
        }
        return o
    }
}
