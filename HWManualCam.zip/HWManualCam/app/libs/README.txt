Optional: if Gradle cannot download com.huawei.multimedia:camerakit, put the Camera Engine SDK (camerakit-*.aar)
from https://developer.huawei.com/consumer/en/CameraKit in this folder and change app/build.gradle.kts to
implementation(files("libs/camerakit-1.1.3.aar")).
