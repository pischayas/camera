# HW Manual Cam
Separate app (com.example.hwmanualcam). Same Camera2 features as ManualCam, plus
Settings > "HW Camera Engine – Pro Video" which opens a screen built on Huawei Camera Engine (camerakit).
Build with the Camera Engine:  gradle assembleDebug -PwithHw=true
Build without it:              gradle assembleDebug
