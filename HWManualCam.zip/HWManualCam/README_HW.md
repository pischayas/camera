# HW Manual Cam
Separate app (com.example.hwmanualcam). Same Camera2 features as ManualCam, plus
Settings > "HW Camera Engine – Pro Video" (Huawei Camera Engine / camerakit).

Camera Engine SDK sources, in priority order:
1. app/libs/camerakit*.aar            (put the SDK downloaded from developer.huawei.com here)
2. com.huawei.multimedia:camerakit:1.1.5 from https://developer.huawei.com/repo/

Build with the Camera Engine:  gradle assembleDebug -PwithHw=true
Build without it:              gradle assembleDebug
